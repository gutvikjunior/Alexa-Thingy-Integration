/**
 * Lambda function for the Thingy skill.
 **/

'use strict';

const Alexa = require('alexa-sdk');
const https = require('https');
const firebase = require('firebase');

// Initialize Firebase
var config = {
  apiKey: "AIzaSyBnErwKDj2hSelFCsTcB8y11w4ddWB4ENQ",
  authDomain: "ourthingyauthentication.firebaseapp.com",
  databaseURL: "https://ourthingyauthentication.firebaseio.com",
  storageBucket: "ourthingyauthentication.appspot.com",
  messagingSenderId: "145732795809"
};
var app = firebase.initializeApp(config);

//Login to Firebase
firebase.auth().signInWithEmailAndPassword("INSERT EMAIL", "INSERT PASSWORD").catch(function(error) {
    // TODO: Handle error
    var errorCode = error.code;
    var errorMessage = error.message;
});

const APP_ID = undefined; // TODO replace with your app ID (OPTIONAL).

const handlers = {
    'LaunchRequest': function () {
        this.attributes.speechOutput = this.t('WELCOME_MESSAGE', this.t('SKILL_NAME'));
        // If the user either does not reply to the welcome message or says something that is not
        // understood, they will be prompted again with this text.
        this.attributes.repromptSpeech = this.t('WELCOME_REPROMT');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'GetTemperature': function () {
        fbGet("/temperature").then(data => {
            this.attributes.speechOutput = this.t('TEMP_MESSAGE', data);
            this.emit(':tell', this.attributes.speechOutput);
        }).catch(e => {
            this.attributes.speechOutput = this.t('GENERAL_ERR');
            this.emit(':tell', this.attributes.speechOutput);
        })
    },
    'GetLedColor': function () {
        fbGet("/led/color").then(data => {
            this.attributes.speechOutput = this.t('GLED_COLOR_MESSAGE', data);
            this.emit(':tell', this.attributes.speechOutput);
        }).catch(e => {
            this.attributes.speechOutput = this.t('GENERAL_ERR');
            this.emit(':tell', this.attributes.speechOutput);
        })
    },
    'SetLedColor': function () {
        // get the color variable from the request
        const colorSlot = this.event.request.intent.slots.Color;
        const modeSlot = this.event.request.intent.slots.Mode;
        let colorName;
        let ledValues;
        if (colorSlot && colorSlot.value) {
            colorName = colorSlot.value.toLowerCase();   
        }
        let modeName = "breathing";
        if (modeSlot && modeSlot.value) {
            modeName = modeSlot.value.toLowerCase();   
        }
        
        ledValues = {color: colorName, mode: modeName};
        // writes to database
        fbPut("/led", ledValues).then(data => {
            this.attributes.speechOutput = this.t('SLED_COLOR_MESSAGE', colorName);
            this.emit(':tell', this.attributes.speechOutput);
        }).catch(e => {
            this.attributes.speechOutput = this.t('GENERAL_ERR');
            this.emit(':tell', this.attributes.speechOutput);
        })
    },
    // Retrieves Temperature and humidity from the database and generates a response.
    'GetBrewingCondition': function () {
        fbGet("/temperature").then(data => {
            let brewingTemp = data;
            	fbGet("/humidity").then(data => {
	              	let brewingHumidity = data;
          	        let response = this.t('CURRENT_BREW_TEMP', brewingTemp);
			        if (brewingTemp < 5){
			            response += this.t('COLD_FERMENTING');
			        } else if (brewingTemp > 25){
			            response += this.t('HOT_FERMENTING');
			        } else{
			            response += this.t('NICE_FERMENTING');
			        }
			        if (brewingHumidity > 30){
			            response += this.t('BREW_HIGH_HUMIDITY');
			        } else {
			            response += this.t('BREW_NICE_HUMIDITY');
			        }
		            this.attributes.speechOutput = this.t(response);
		            this.emit(':tell', this.attributes.speechOutput);
		        }).catch(e => {
		            this.attributes.speechOutput = this.t('GENERAL_ERR');
		            this.emit(':tell', this.attributes.speechOutput);
		        })
        }).catch(e => {
            this.attributes.speechOutput = this.t('GENERAL_ERR');
            this.emit(':tell', this.attributes.speechOutput);
        })
    },
    // Retrieves Co2 and TVOC levels from the database and generates a response.
    'GetAirQuality': function () {
        fbGet("/eco2").then(data => {
            let eco2 = data;

            fbGet("/tvoc").then(data => {
                let tvoc = data;
                let response = this.t('AIR_QUALITY_MESSAGE', eco2, tvoc);

                if (eco2 > 1000) {
                    response += this.t('BAD_CO2_MESSAGE');
                } else {
                    response += this.t('GOOD_CO2_MESSAGE');
                }

                if (tvoc > 10000) {
                    response += this.t('BAD_TVOC_MESSAGE');
                } else if (tvoc > 1000){
                    response += this.t('MARGINAL_TVOC_MESSAGE');
                } else {
                    response += this.t('GOOD_TVOC_MESSAGE');
                }
                
                this.attributes.speechOutput = this.t(response);
                this.emit(':tell', this.attributes.speechOutput);
            }).catch(e => {  
                this.attributes.speechOutput = this.t('GENERAL_ERR');
                this.emit(':tell', this.attributes.speechOutput);
            })
        }).catch(e => {
            this.attributes.speechOutput = this.t('GENERAL_ERR');
            this.emit(':tell', this.attributes.speechOutput);
        })
    },
    'AMAZON.HelpIntent': function () {
        this.attributes.speechOutput = this.t('WELCOME_MESSAGE');
        this.attributes.repromptSpeech = this.t('HELP_REPROMT');
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.RepeatIntent': function () {
        this.emit(':ask', this.attributes.speechOutput, this.attributes.repromptSpeech);
    },
    'AMAZON.StopIntent': function () {
        this.emit('SessionEndedRequest');
    },
    'AMAZON.CancelIntent': function () {
        this.emit('SessionEndedRequest');
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

const languageStrings = {
    'en-US': {
        translation: {
            SKILL_NAME: 'The Thingy Project',
            WELCOME_MESSAGE: "yo.",
            WELCOME_REPROMT: 'For instructions on what you can say, please say help me.',
            HELP_MESSAGE: "You can ask me stuff.",
            HELP_REPROMT: "Got it?",
            STOP_MESSAGE: 'Goodbye!',

            TEMP_MESSAGE: 'The temperature is %s degrees.',
            GENERAL_ERR: 'Something went wrong. Please try again later.',
            NOT_FOUND_ERR: 'Found nothing! Are you sure your Thingy is connected?',
            GLED_COLOR_MESSAGE: 'The color of the LED is %s.',
            SLED_COLOR_MESSAGE: 'The color of the LED set to %s.',
            LOCATION_MESSAGE: 'Thingy is located at %s',
            CURRENT_BREW_TEMP: 'Your current brewing temperature is %s degrees.',
            COLD_FERMENTING: ' This seems a bit cold for fermenting your brew. Maybe you should crank it up?',
            HOT_FERMENTING: ' This seems a bit hot for fermenting your brew. Maybe you should cool it down?',
            NICE_FERMENTING: ' This seems to be a nice temperature for fermenting your brew. Keep up the good work.',
            BREW_HIGH_HUMIDITY: ' It seems as though you have high humidity in your brewing location, at over 30%. Make sure to dry your equipment properly.',
            BREW_NICE_HUMIDITY: ' The humidity in your brewing location seems very good, at below 30%.',
            AIR_QUALITY_MESSAGE: 'The CO2 content is %s parts per million, and the total volatile organic compounds is %s parts per billion. ',
            BAD_CO2_MESSAGE: 'The CO2 level is considered above the accepted amount of a thousand parts per million. ',
            GOOD_CO2_MESSAGE:'The CO2 level is considered good, and below the maximum accepted amount of a thousand parts per million. ',
            GOOD_TVOC_MESSAGE: 'The total volatile organic compounds level is good.',
            MARGINAL_TVOC_MESSAGE: 'The total volatile organic compounds level is considered marginal.',
            BAD_TVOC_MESSAGE: 'The total volatile organic compounds level is considered bad. Get out of there!',
        },
    },
};

function fbGet(key){
    return new Promise((resolve, reject) => {
        var firebaseRef = firebase.database().ref(key);
        firebaseRef.once('value').then((datasnapshot) =>{
            resolve(datasnapshot.val());
        }, (error) => {
            reject(error);
        })
    })
}

function fbPut(key, value){
    return new Promise((resolve, reject) => {
        var firebaseRef = firebase.database().ref(key);
        firebaseRef.set(value).then((value) =>{
            resolve(value);
        }, (error) => {
            reject(error);
        })
    })
}

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
