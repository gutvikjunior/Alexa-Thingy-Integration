# it2901lambda
The lambda function of our it2901 project

## How to install
Run "npm install".
