var noble = require('noble');
const firebase = require('firebase');

var firebase_email = "INSERT FIREBASE EMAIL HERE";
var firebase_password = "INSERT FIREBASE PASSWORD HERE";

const macAddress = "INSERT MAC ADDRESS OF PERIPHERAL BLE DEVICE HERE";

// Initialize Firebase
var config = {
  apiKey: "AIzaSyBnErwKDj2hSelFCsTcB8y11w4ddWB4ENQ",
  authDomain: "ourthingyauthentication.firebaseapp.com",
  databaseURL: "https://ourthingyauthentication.firebaseio.com",
  storageBucket: "ourthingyauthentication.appspot.com",
  messagingSenderId: "145732795809"
};
var app = firebase.initializeApp(config);

// Må gjøres som callback fra login for å sikre at man er logget innn først
//getTemperature();
//setLED("red");

function fbStartLedListener(){
    console.log("Trying to listen");
    return new Promise((resolve, reject) => {
        var ledRef = firebase.database().ref('led');
        ledRef.on('value', (datasnapshot) =>{
            DBLedChangeReceived(datasnapshot.val());
        })
    })
}

function getTemperature(){
	fbGet("/temperature").then(data => {
			console.log("The temperature is " + data);
	}).catch(e => {
			console.log(e);
	})
}

function setLED(colorName){
	fbPut("/led", colorName).then(data => {
			console.log("Led set to " + colorName);
	}).catch(e => {
			console.log(e);
	})
}

function setTemperature(newTempValue){
    fbPut("/temperature", newTempValue).then(data => {
            console.log("Temperature updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setPressure(newPressureValue){
    fbPut("/pressure", newPressureValue).then(data => {
            console.log("Pressure updated in DB");
    }).catch(e => {
            console.log(e);
    })
}


function setHumidity(newHumidityValue){
    fbPut("/eco2", newHumidityValue).then(data => {
            console.log("Humidity updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setECO2(newECO2Value){
    fbPut("/eco2", newECO2Value).then(data => {
            console.log("eCO2 updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setTVOC(newTVOCValue){
    fbPut("/tvoc", newTVOCValue).then(data => {
            console.log("tvoc updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setColorsensor(newColorsensorValue){
    fbPut("/colorsensor", newColorsensorValue).then(data => {
            console.log("colorsensor updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setTap(newTapDirection, newTapCount){
    fbPut("/tap/direction", newTapDirection).then(data => {
            console.log("tap direction updated in DB");
    }).catch(e => {
            console.log(e);
    })
    fbPut("/tap/count", newTapCount).then(data => {
            console.log("tap count updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setXCoordinate(coord){
	fbPut("/location/x", coord).then(data => {
            console.log("X coordinate updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

function setYCoordinate(coord){
	fbPut("/location/y", coord).then(data => {
            console.log("Y coordinate updated in DB");
    }).catch(e => {
            console.log(e);
    })
}

//Read data from Firebase
function fbGet(key){
    return new Promise((resolve, reject) => {
        var firebaseRef = firebase.database().ref(key);
        firebaseRef.once('value').then((datasnapshot) =>{
            resolve(datasnapshot.val());
        }, (error) => {
            reject(error);
        })
    })
}

//Write data to Firebase
function fbPut(key, value){
    return new Promise((resolve, reject) => {
        var firebaseRef = firebase.database().ref(key);
        firebaseRef.set(value).then((value) =>{
            resolve(value);
        }, (error) => {
            reject(error);
        })
    })
}

//------------------------------ END FIREBASE -------------------------


var loggedInToFirebase = false;

var thingyPeripheral;
var characteristicSubscriptions = [];
// Services and characteristics used:
const thingyConfigService = "ef6801009b3549339b1052ffa9740042";
const thingyConfigServiceShort = "0100";
const thingyName = "ef6801019b3549339b1052ffa9740042";
const thingyNameShort = "0101";
const cloudToken = "ef6801069b3549339b1052ffa9740042";
const cloudTokenShort = "0106";

const weatherService = "ef6802009b3549339b1052ffa9740042";
const weatherServiceShort = "0200";
const temperatureUuid = "ef6802019b3549339b1052ffa9740042";
const temperatureUuidShort = "0201";
const pressureUuid = "ef6802029b3549339b1052ffa9740042";
const pressureUuidShort = "0202";
const humidityUuid = "ef6802039b3549339b1052ffa9740042";
const humidityUuidShort = "0203";
const gasUuid = "ef6802049b3549339b1052ffa9740042";
const gasUuidShort = "0204";
const colorUuid = "ef6802059b3549339b1052ffa9740042";
const colorUuidShort = "0205";
const weatherConfig = "ef6802069b3549339b1052ffa9740042";
const weatherConfigShort = "0206";

const uiService = "ef6803009b3549339b1052ffa9740042";
const uiServiceShort = "0300";
const ledUuid = "ef6803019b3549339b1052ffa9740042";
const ledUuidShort = "0301";
const buttonUuid = "ef6803029b3549339b1052ffa9740042";
const buttonUuidShort = "0302";

const motionService = "ef6804009b3549339b1052ffa9740042";
const tapUuid = "ef6804029b3549339b1052ffa9740042";
const tapUuisShort = "0402";
const orientationUuid = "ef6804039b3549339b1052ffa9740042";
const orientationUuidShort = "0403"
const quaternionUuid = "ef6804049b3549339b1052ffa9740042";
const quaternionUuidShort = "0404"
const pedometerUuid = "ef6804059b3549339b1052ffa9740042";
const pedometerUuidShort = "0405"
const rawDataUuid = "ef6804069b3549339b1052ffa9740042";
const rawDataUuidShort = "0406";

/*
Registers an event listener that disconnects Thingy (if connected)
before exiting the script when interrupted on signal-interrupt (e.g. CTRL+C in console)
*/
process.on('SIGINT', function() {
	  if (thingyPeripheral != null){
	  	disconnectPeripheral();
	  }

	  process.exit();
	});
/* Registers a listener for the 'stateChange' event, which starts scanning when adapter is powered on
	state : state of the bluetooth adapter */
noble.on('stateChange', function(state){
	console.log(state);

	if(state === 'poweredOn'){
		noble.startScanning();
	}
	else{
		noble.stopScanning();
	}
});


/* Registers a listener for the 'discover' event, that is: when a peripheral device has been discovered by the bluetooth adapter's scanning
	When the specified MAC address has been found, the listener stops scanning and tries to connect to that device */	
noble.on('discover', function(peripheral){
	if(peripheral.uuid == macAddress){
		noble.stopScanning();
		console.log("----------");
		connectPeripheral(peripheral);
		}
});

/* Runs the connect function on the peripheral argument
   and specifies an anonymous callback function for the response of the connect attempt
   If the callback has no error, register listeners for 'disconnect' and 'servicesDiscover,
   and than try to discover services from the peripheral*/
function connectPeripheral(peripheral){

	peripheral.connect(function(error){

		if(error == null){
			thingyPeripheral = peripheral;
			thingyPeripheral.once('disconnect', onPeripheralDisconnected);
			console.log("Successfully connected. Attempting to discover services..");
			thingyPeripheral.once('servicesDiscover', onServicesDiscovered);
			thingyPeripheral.discoverServices([weatherService, uiService, motionService]);


			/*setTimeout(function() {
				disconnectPeripheral()}, 5000);
		}*/
		}

		else {
			console.log("An error occurred during an attempt to connect to peripheral: ", error);
		}
		console.log("-------------");
	});
}
/* Invoked as callback when services has been discovered from the peripheral
	If the received services is a valid collection, try to discover characteristics of those services	*/
function onServicesDiscovered(services){
	//printServices(services);
	if (isValidCollection(services)) {
		console.log("Services found");
		discoverCharacteristics(services);
	}
	else {
		console.log("Could not receive services correctly");
	}
}

/*	Checks if a collection has elements */
function isValidCollection(collection){
	return (collection != null && collection.length > 0);
}

/* Iterates through a collection of services and tries to discover their (specific) characteristics	*/
function discoverCharacteristics(services){
	if (isValidCollection(services)) {
		for (let service of services) {
			service.once('characteristicsDiscover', onCharacteristicsDiscovered);
			service.discoverCharacteristics([weatherConfig, ledUuid, temperatureUuid, pressureUuid, humidityUuid, gasUuid, colorUuid, buttonUuid, rawDataUuid]);
		}
	}
	else{
		console.log("Could not discover characteristics for the given service(s)");
	}
}

/* Invoked on callback when characterstics have been discovered for a given service.
	Configures desired operations for those characteristics */

function onCharacteristicsDiscovered(characteristics){
	if (isValidCollection(characteristics)){
		console.log("Characteristics discovered..");
		configureInitialOperations(characteristics);
	}
	else {
		console.log("Did not receive valid characteristics");
	}
}

/*
Uses the short UUID of to identify each characteristic,
and then performs an appropriate configuration operation
*/

function configureInitialOperations(characteristics){
	for (let char of characteristics){
		let shortUuid = char.uuid.substr(4, 4);
		if (shortUuid == weatherConfigShort){
			configureWeatherUpdates(char);
		}

		else if (shortUuid == ledUuidShort){
			/*char.on('data', ledUpdateReceived);
			char.read();*/

			ledWriteResponse(null);

		}
		else if(shortUuid == temperatureUuidShort){
			char.on('data', temperatureUpdateReceived);
			subscribeToCharacteristic(char);
		}
		else if(shortUuid == pressureUuidShort){
			char.on('data', pressureUpdateReceived);
			subscribeToCharacteristic(char);
		}
		else if(shortUuid == humidityUuidShort){
			char.on('data', humidityUpdateReceived);
			subscribeToCharacteristic(char);
		}
		else if(shortUuid == gasUuidShort){
			char.on('data', gasUpdateReceived);
			subscribeToCharacteristic(char);
		}
		else if (shortUuid == colorUuidShort){
			char.on('data', colorUpdateReceived);
			subscribeToCharacteristic(char);
		}
		else if(shortUuid == buttonUuidShort) {
			char.on('data', buttonUpdateReceived);
			subscribeToCharacteristic(char);
		}
    else if(shortUuid == tapUuisShort){
			char.on('data', tapUpdateReceived);
			subscribeToCharacteristic(char);
    }
    else if(shortUuid == orientationUuidShort){
			char.on('data', orientationUpdateReceived);
			subscribeToCharacteristic(char);
    }
    else if(shortUuid == quaternionUuidShort){
			char.on('data', quaternionUpdateReceived);
			subscribeToCharacteristic(char);
    }
    else if(shortUuid == pedometerUuidShort){
			char.on('data', pedometerUpdateReceived);
			subscribeToCharacteristic(char);
    }
    else if(shortUuid == rawDataUuidShort){
			char.on('data', rawDataReceived);
			subscribeToCharacteristic(char);
		}
	}
}

/*
Writes to the configuration characteristic to set update interval to 4096
*/
function configureWeatherUpdates(characteristic){
	//Buffer: uint16: 4096ms four times , uint8: 2 = 10s

	const writeBuffer = Buffer.from([0x00, 0x10, 0x00, 0x10, 0x00, 0x10, 0x00, 0x10, 0x02]);
	characteristic.write(writeBuffer, false, weatherConfigurationResponseReceived);

}
/* Logs the outcome of write to weather configuration characteristic*/
function weatherConfigurationResponseReceived(error){
	if (error == null){
		console.log("Successfully configured weather updates");
	}
	else{
		console.log(error);
	}
}
/* Not used atm. */
function initiateCharacteristicRead(characteristic, callback){
	characteristic.once('data', callback);
	characteristic.read();
}
/* Not used atm. */
function ledUpdateReceived(data, isNotificationFlag){
	logReceivedUpdate("LED", data);
	let modeByte = data.readUInt8(0);
	let colorByte = 0;
	switch (modeByte) {
		case 0:
			// LED off
			break;
		case 1:
			// constant
				//uint8_t - R intensity - (0 - 255)
				//uint8_t - G intensity - (0 - 255)
				//uint8_t - B intensity - (0 - 255)
			break;
		default:
			colorByte = data.readUInt8(1);
			return;
	}
	if (colorByte > 0){
		let colorString = byteToString(colorByte);
		fbPut("/led", colorString);
	}

}

/* Attempts to subscribe to the given characteristic
	If successful, it adds the characteristic to the characteristicSubscriptions collection */
function subscribeToCharacteristic(characteristic){
	characteristic.subscribe(function(error){
		if (error == null){
			console.log("Successfull subscription to: ", characteristic.uuid);
			characteristicSubscriptions.push(characteristic);
		}
		else {
			console.log("Encountered error on attempt to subscribe: ", error);
		}
	});
}

/*Invoked when Thingy's temperature sensor updates*/

function temperatureUpdateReceived(data, isNotificationFlag){
	const value = data.readUInt8(0);
	logReceivedUpdate("TEMP", value);

	if(loggedInToFirebase){
		setTemperature(value);
	}
}
/*Invoked when Thingy's pressure sensor updates*/

function pressureUpdateReceived(data, isNotificationFlag){
	const value = data.readInt32LE(0);
	logReceivedUpdate("PRESSURE", value);

	if(loggedInToFirebase){
		setPressure(value);
	}
}

/*Invoked when Thingy's humidity sensor updates*/

function humidityUpdateReceived(data, isNotificationFlag){
	const value = data.readUInt8(0);
	logReceivedUpdate("HUMIDITY", value);

	if(loggedInToFirebase){
		setHumidity(value);
	}
}
/*Invoked when Thingy's air quality sensor updates*/

function gasUpdateReceived(data, isNotificationFlag){
	const eco2 = data.readUInt16LE(0);
	const tvoc = data.readUInt16LE(1);
	logReceivedUpdate("ECO2", eco2);
	logReceivedUpdate("TVOC", tvoc);

	if(loggedInToFirebase){
		setECO2(eco2);
		setTVOC(tvoc);
	}

}
/*Invoked when Thingy's color sensor updates*/
function colorUpdateReceived(data, isNotificationFlag){
	const red = data.readUInt16LE(0);
	const green = data.readUInt16LE(2);
	const blue = data.readUInt16LE(4);
	const clear = data.readUInt16LE(6);
	//var color;
	//setColorsensor(color);
}
/* Invoked when state of Thingy's button updates */
function buttonUpdateReceived(data, isNotificationFlag){
	logReceivedUpdate("BUTTON", data);
	disconnectPeripheral();
}

/*Invoked when Thingy's tap sensor updates*/
function taUpdateReceived(data, isNotificationFlag){
	const direction = byteToDirection(data.readUInt8(0));
  const count = data.readUInt8(1);
	logReceivedUpdate("Direction", direction);
	logReceivedUpdate("Count", count);
	if(loggedInToFirebase){
	   setTap(direction, count);
	}

/* Invoked when Thingy's raw data characteristic is updated	*/
function rawDataReceived(data, isNotificationFlag){
	let parsedXYArray = parseRawData(data);
	/*setXCoordinate(parsedXYArray[0]);
	setYCoordinate(parsedXYArray[1]);*/
	logReceivedUpdate("X: ", parsedXYArray[0]);
	logReceivedUpdate("Y: ", parsedXYArray[1]);

}
/* Parses the Buffer of bytes received.
	Returns x and y coordinate in an array */

function parseRawData(rawDataBuffer){
	let xyBuffer = rawDataBuffer.slice(12, 16);
	let x = xyBuffer.readInt16LE(0);
	let y = xyBuffer.readInt16LE(2);
	let arr = [x, y];
	return arr;
}

/*Logs an update to the console*/
function logReceivedUpdate(charactersticType, data){
	console.log(charactersticType, " read received: ", data);
}

/*Iterates through a collection of services, and prints their uuids*/
function printServices(services){
	if (services != null){
		for (var i = 0; i <= services.length - 1; i++) {
			console.log("Service ", i, ": ", services[i].uuid);
		}
	}
}
/* Some test function, not used atm. */
function writeCharacteristic(characteristic){
	var buffer = Buffer.from('Test', 'ascii');
	characteristic.write(buffer, true, function(error){
		console.log("written");
		printError(error);
	});
}
/* Invoked when LED characterstic has been found
Acts as a temporary solution for ensuring that Firebase sign-in is performed AFTER Thingy is connected
 This is necessary because the signed-in event starts the Firebase value listener that tries to write to the LED characteristic
 The write-operation will cause an error if the LED characteristic does not exist 	*/
function ledWriteResponse(error){
	if (error == null){

		if(!loggedInToFirebase){
			//Login to Firebase
			firebase.auth().signInWithEmailAndPassword(firebase_email, firebase_password).then(function(){
				console.log("Got signed in!");
				fbStartLedListener();
			}).catch(function(error) {
				// Handle Errors here.
				var errorCode = error.code;
				var errorMessage = error.message;
				// ...
			});

			loggedInToFirebase = true;
		}


	}
	else{
		console.log("Something went wrong: ", error);
	}

}
/* Unsubscribes to relevant characteristics, and disconnects the peripheral device	*/
function disconnectPeripheral(){
	console.log("Trying to disconnect..");
	if (isValidCollection(characteristicSubscriptions)){
		console.log("Unsubscribing..");
		for (let char of characteristicSubscriptions){
			char.unsubscribe(function(error){
				if (error == null){
					console.log("Successfully unsubsrcibed to ", char.uuid);
				}
				else {
					console.log("Could not unsubscribe");
				}
			});
		}
	}
	thingyPeripheral.disconnect();

}
/* Invoked as callback when the peripheral has disconnected from this device.
   Exits the script */
function onPeripheralDisconnected(){
	console.log("Successfully disconnected");
	process.exit();
}


/* Is invoked each time an update occurs in the Firebase field LEDcolor.
   When invoked, it searches for the LED characteristic object.
   This characteristic object is needed for performing the write operation to Thingy */

function DBLedChangeReceived(value){
	let ledCharacteristic = null;

	let ledService = findService(uiServiceShort);
	if (ledService != null){
		ledCharacteristic = findCharacteristic(ledService, ledUuidShort);
	}
	if(ledCharacteristic != null){
		writeLed(ledCharacteristic, value);
	}
}

/* Writes the given color to the characteristic */

function writeLed(characteristic, colorName){

	let colorbyte = colorToByte(colorName);
	if (colorbyte > 0){
		//Write: breathe-mode, 8-bit color, 50% intensity, 1500ms delay
		let writebuffer = Buffer.from([2, colorbyte, 50, 1500, 5]);
		//characteristic.once('write', false, ledWriteResponse);
		characteristic.write(writebuffer, false, ledWriteResponse);
	}

}
/* Searches through the peripherals collection of services for the service with shortuuid equal to targetServiceShortUuid
	If found, it returns that service object
	Else it returns null 	*/
function findService(targetServiceShortUuid){
	if (thingyPeripheral != null){
		let services = thingyPeripheral.services;
		if (isValidCollection(services)){
			for (let service of services){
				let shortUuid = service.uuid.substr(4, 4);
				if (shortUuid == targetServiceShortUuid){
					return service;
				}
			}

		}
	}
	return null;
}
/* Searches through the characteristics collection of the service argument, for the characteristic with shortUuid equal to targetCharShortUuid
		Returns that Characteristic object if found, else returns null
	*/
function findCharacteristic(service, targetCharShortUuid){
	let characteristics = service.characteristics;
	if (isValidCollection(characteristics)){
		for (let char of characteristics){
			if (char.uuid.substr(4, 4) == targetCharShortUuid){
				return char;
			}
		}
	}
	return null;
}

//Converts byte from tap characterisitc to axis string
function byteToDirection(directionValue){
  let direction = "";
  switch (directionValue) {
    case 1:
      direction = "x-axis up"
      break;
    case 2:
      direction = "x-axis down"
      break;
    case 3:
      direction = "y-axis up"
      break;
    case 4:
      direction = "y-axis down"
      break;
    case 5:
      direction = "z-axis up"
      break;
    case 6:
      direction = "z-axis down"
      break;
    default:
      direction = "undefined"
  }
  return direction;
}

/* Parses a color value (as byte) to a color name (string)	*/

function byteToString(colorValue){
	let color = "";
	switch (colorValue){
		case 1:
			color = "red";
			break;
		case 2:
	        color = "green"
	        break;
	    case 3:
	    	color = "yellow";
	    	break;
	    case 4:
	    	color = "blue";
	    	break;
	    case 5:
	    	color = "purple";
	    	break;
	    case 6:
	    	color = "cyan";
	    	break;
	    case 7:
	    	color = "white";
	    default:
	      	color = "undefined";
	}
	return color;
}
/* Parses a color name to the appropriate byte for Thingy	*/
function colorToByte(colorstring){
	let colorValue;
	switch (colorstring){
		case "red":
			colorValue = 1;
			break;
		case "green":
			colorValue = 2;
	        break;
	    case "yellow":
	    	colorValue = 3;
	    	break;
	    case "blue":
	    	colorValue = 4;
	    	break;
	    case "purple":
	    	colorValue = 5;
	    	break;
	    case "cyan":
	    	colorValue = 6;
	    	break;
	    case "white":
	    	colorValue = 7;
	    	break;

	    default:
	      	colorValue = 0;
	}
	return colorValue;
}

function printError(error){
	console.log("Error: " + error);
}
